import React from 'react';
import {StyleSheet, Text, View, Image, TouchableOpacity} from 'react-native';

const TheThing = ({onBtnPress, isBtnDisabled, imgSourceObject, btnText}) => {
  console.log('imgSourceObject', imgSourceObject);
  return (
    <View>
      {imgSourceObject.uri !== '' && (
        <View>
          <Image
            style={sty.img}
            resideMode="contain"
            source={imgSourceObject}
          />
        </View>
      )}
      <TouchableOpacity
        onPress={onBtnPress}
        disabled={isBtnDisabled}
        style={{backgroundColor: isBtnDisabled ? 'red' : 'green'}}>
        <Text>{btnText}</Text>
      </TouchableOpacity>
    </View>
  );
};

export default React.memo(TheThing);

const sty = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'beige',
    justifyContent: 'center',
    alignItems: 'center',
  },
  dataText: {
    fontSize: 15,
    color: 'black',
  },
  img: {
    width: 100,
    height: 100,
  },
});
