import {GET_RANDOMPIC, SET_RANDOMPIC} from '../types';
//__BUNDLE_START_TIME__

export const start_get_random = () => {
  return {type: START_GET_RANDOM};
};

export const call_getRandomPic_action = () => {
  return {
    type: GET_RANDOMPIC,
  };
};

export const setRandomPic_action = data => {
  return {
    type: SET_RANDOMPIC,
    payload: data,
  };
};
