import {createStore, combineReducers, applyMiddleware} from 'redux';
import createSagaMiddleware from 'redux-saga';
import {defaultReducer} from './reducers/defaultReducer';
import {randomPicReducer} from './reducers/randomPicReducer';
import {watcherSaga} from './sagas'; //THIS

export const rootReducer = combineReducers({
  defaultReducer,
  randomPicReducer,
});

const sagaMiddleware = createSagaMiddleware();

const store = createStore(rootReducer, applyMiddleware(sagaMiddleware));

sagaMiddleware.run(watcherSaga);

export let sagaStore = store;
