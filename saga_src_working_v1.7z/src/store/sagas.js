import {takeLatest, call, put, all} from 'redux-saga/effects';
import {GET_TEST_DATA, API_CALL_FAILURE, GET_RANDOMPIC} from './types';
import axios from 'axios';
import {some_set_api_TestAction} from './actions/defaultActions';
import {setRandomPic_action} from './actions/randomPicActions';

function* dogSaga() {
  yield takeLatest(GET_TEST_DATA, dogWorkerSaga);
}

function* randomPicSaga() {
  yield takeLatest(GET_RANDOMPIC, randomWorkerSaga);
}

export function* watcherSaga() {
  yield all([dogSaga(), randomPicSaga()]);
}

// function that makes the api request and returns a Promise for response
function fetchDog() {
  return axios({
    method: 'get',
    url: 'https://dog.ceo/api/breeds/image/random',
  });
}

function fetchRandomPic() {
  return axios({
    method: 'get',
    url: 'https://picsum.photos/200',
  });
}

// worker saga: makes the api call when watcher saga sees the action
function* dogWorkerSaga() {
  try {
    const response = yield call(fetchDog);
    const dog = response.data.message;

    // dispatch a success action to the store with the new dog
    yield put(some_set_api_TestAction(dog));
  } catch (error) {
    // dispatch a failure action to the store with the error
    yield put({type: API_CALL_FAILURE, error});
  }
}

function* randomWorkerSaga() {
  try {
    const response = yield call(fetchRandomPic);
    console.log('randompic response ', response.request.responseURL);

    yield put(setRandomPic_action(response.request.responseURL));
  } catch (error) {
    //todo
    console.log('error randomWorkerSaga ', error);
  }
}
