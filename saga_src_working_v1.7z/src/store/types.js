export const API_CALL_FAILURE = 'API_CALL_FAILURE';

export const START_GET_DATA = 'START_GET_DATA';
export const GET_TEST_DATA = 'GET_TEST_DATA'; //http request
export const SET_TEST_DATA = 'SET_TEST_DATA';

export const START_GET_RANDOM = 'START_GET_RANDOM';
export const GET_RANDOMPIC = 'GET_RANDOMPIC'; //http request
export const SET_RANDOMPIC = 'SET_RANDOMPIC';
